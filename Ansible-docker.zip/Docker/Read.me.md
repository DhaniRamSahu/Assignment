1. Create Bridge docker network with name hu-devops

```
docker network create hu-devops
```

![image-20210714102120497](C:\Users\Ram\AppData\Roaming\Typora\typora-user-images\image-20210714102120497.png)

Build image using docker file

```
docker build -f Dockerfile -t hello-python-flask:latest .
```

![image-20210714103226894](C:\Users\Ram\AppData\Roaming\Typora\typora-user-images\image-20210714103226894.png)

Create a container with image in hu-devops

```
docker run --name my-flask-app --network hu-devops --publish 5005:5000 hello-python-flask
```

![image-20210714103339645](C:\Users\Ram\AppData\Roaming\Typora\typora-user-images\image-20210714103339645.png)

Output:

![image-20210714103450288](C:\Users\Ram\AppData\Roaming\Typora\typora-user-images\image-20210714103450288.png)

2. Creating docker nginx custom image with custom nginx.conf file for proxy

![image-20210715085403994](C:\Users\Ram\AppData\Roaming\Typora\typora-user-images\image-20210715085403994.png)

Create a container with image

```
docker run --name nginx-contnr --network hu-devops --publish 5006:80 ngnix-cust-img
```

![image-20210715085538309](C:\Users\Ram\AppData\Roaming\Typora\typora-user-images\image-20210715085538309.png)

after that flask application will be accessible via nginx container

![image-20210715085713194](C:\Users\Ram\AppData\Roaming\Typora\typora-user-images\image-20210715085713194.png)

3. mount file form container to local host

```
docker cp nginx-container:/home/logs/ ./logs
```

![image-20210715003047206](C:\Users\Ram\AppData\Roaming\Typora\typora-user-images\image-20210715003047206.png)



