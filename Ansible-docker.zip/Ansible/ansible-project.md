1. Setup ansible with Ubuntu and Centos

![image-20210715204259425](C:\Users\Ram\AppData\Roaming\Typora\typora-user-images\image-20210715204259425.png)

![image-20210715204326421](C:\Users\Ram\AppData\Roaming\Typora\typora-user-images\image-20210715204326421.png)



2. create an ansible playbook to create a file on the managed node as
   /opt/hashedin.txt with any content and copy the same file to the
   control node from the managed node at any location.

```
- hosts: all
  tasks:
   - name: Ansible create file with content
     copy:
         dest: "/opt/hashedin.txt"
         content: |
                Testing	
- hosts: node1
  tasks:
	- name: Copy file from worker to controler 
      shell: scp /opt/hashedin.txt ubuntu@3.108.219.9:/home/ubuntu 
```



